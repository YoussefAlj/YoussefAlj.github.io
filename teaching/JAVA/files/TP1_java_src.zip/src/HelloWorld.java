public class HelloWorld{
	String message;
	// Le constructeur
	HelloWorld(String valeur){
		message = valeur;
	}
	// La methode qui renvoie le message
	public String getMessage(){
		return message;
	}
	public static void main(String [] args){
		// creation d une nouvelle instance de la classe HelloWorld2
		HelloWorld instance = new HelloWorld("Bonjour tout le monde");
		// appel de la methode getMessage() et affichage du resultat
		System.out.println(instance.getMessage());
	}
}