
/* exemple
bonjour tout le monde
le nombre d'occurence = nombre d'apparition
La fréquence = le nombre d'occurence/le nombre total de caractères
La frequence de la lettre 'e' est 2/19
*/

// standard input output
#include <stdio.h>

//signature de la fonction
float frequence(char texte[] , char lettre);

int main(){
		
	//lire la chaine de caractere
	int MAXI = 1000;
	char ligne [MAXI ] ;
	printf("veuillez saisir une chaine de caractères\n");
	gets ( ligne ) ;
	
	//lire le caractere dont on souhaite caluler la fréquence
	char c;
	printf("saisissez un caractère\n");
	scanf("%c", &c);
	
	//appel de la fonction frequence
	float resultat = frequence(ligne, c);
	
	//on affiche le resultat
	printf("La frequence de la lettre %c est %f", c, resultat);
	
	return 0;
}


// definir la fonction frequence
float frequence(char texte[] , char lettre){
	
	int compt_caracteres=0, compt_lettre=0;
	
	float freq;
	
	//compter le nombre total de caractères
	//compter le nombre d'occurence de la lettre lettre
	// '\0' caractere de fin de chaine
	int i;
	for(i=0; texte[i] != '\0'; i++){
		compt_caracteres++;
		if (texte[i] == lettre){
			compt_lettre++;
		}
	}		
	printf("compt_lettre=%d\n", compt_lettre);
	printf("compt_caracteres=%d\n", compt_caracteres);

	freq = (float) compt_lettre/compt_caracteres;
	
	return freq;
}

