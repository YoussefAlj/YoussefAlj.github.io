#include <stdio.h>

int main(){

	int minutes;
	printf("veuillez saisir les minutes\n");
	scanf("%d", &minutes);
	
	int heures = minutes/60;
	int minutes = minutes%60;
	printf("%d h %d min", heures, minutes);
}