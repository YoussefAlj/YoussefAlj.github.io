#include <stdio.h>

// declaration de factorielle
// il faut connaitre 3 choses : 1) type de retour 2) nom de la fonction 3) le nombre de parametres et leur type
int factorielle(int n);

int main(){
	int n;
	printf("veuillez saisir un nombre\n");
	scanf("%d", &n);
	
	// appel de la fonction factorielle 	
	printf("La factorielle de %d est %d", n, factorielle(n));
}

// definition de factorielle
int factorielle(int n){
	
	int i, resultat=1;
	for (i=1; i<= n; i++){
		//pour i = 1, resultat = 1 * 1 = 1
		//pour i = 2, resultat = 1 * 2 = 2
		//pour i = 3, resultat = 2 * 3 = 6
		//pour i = 4, resultat = 6 * 4 = 24
		resultat = resultat*i;
	}
	return resultat;
}