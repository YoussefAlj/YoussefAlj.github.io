#include <stdio.h>

// declaration de factorielle
// il faut connaitre 3 choses : 1) type de retour 2) nom de la fonction 3) le nombre de parametres et leur type
int factorielle(int n);

int main(){
	int n;
	printf("veuillez saisir un nombre\n");
	scanf("%d", &n);
	
	// appel de la fonction factorielle 	
	printf("La factorielle de %d est %d", n, factorielle(n));
}

// definition de factorielle avec la méthode récursive
int factorielle(int n){
	
	//calcul recursif de la factorielle
	
	
	return resultat;
}