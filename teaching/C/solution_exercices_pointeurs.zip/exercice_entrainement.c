#include<stdio.h>

int main()
{
	float a=12;
	float *p=&a;

	*p=19;
	printf(" a %f", a);
}
