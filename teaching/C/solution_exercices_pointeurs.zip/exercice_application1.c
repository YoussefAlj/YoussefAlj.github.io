#include<stdio.h>


int main()
{ 
   int a,b;
   int somme;
   // on declre deux pointeurs
   int *p1,*p2;
   // on remplit a et b
   printf("saisir les deux nombres\n");
   scanf("%d%d",&a,&b);
   // on fait pointer p1 sur a
   // on fait pointer p2 sur b
   p1=&a;
   p2=&b;
   
  somme=*p1+*p2;
  printf("la somme des deux nombres est:%d",somme);
  return 0;
  }
