#include <stdio.h>
// programme qui compte le nombre d'apparition de la lettre 'e' dans une chaine de caracteres
int main(){
	int max = 1000;
	int compteur_e=0;
	char ligne[max];
	puts("veuillez saisir une chaine de caracteres");
	gets(ligne);
	
	int i;
	// on s'arrête si le caractères est le caractère nulle '\0'
	for (i=0; ligne[i] != '\0'; i++)
	{
		// lorsqu'on tombe sur e on incrémente le compteur
		if (ligne[i] == 'e'){
			compteur_e++;
		}
	}
	printf("le nombre d'occurences de la lettre 'e' est %d", compteur_e);
}